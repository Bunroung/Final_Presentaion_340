package com.example.files.thecoachspace;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.files.theadminspace.FileDocument;
import com.example.files.model.User;
import com.example.files.repository.UserRepository;
import com.example.files.theadminspace.FileContentView;
import com.example.files.theadminspace.FileStorageService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.example.files.theadminspace.FileDocumentRepository;
import org.springframework.ui.Model;
import java.io.IOException;
import java.util.*;

@Controller
@RequestMapping("/user")
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/login")
    public String verifyLogin(HttpServletRequest request, String username, String password) {
        System.out.println("request: " + request);
        System.out.println("request.session: " + request.getSession());
        System.out.println(">> username: " + username);
        User user = userRepository.findByUsernameAndPassword(username, password);
        System.out.println(">> user : " + user);

        if (user == null) {
            return "login";
        }

        System.out.println(">> user role: : " + user.getRole());
        HttpSession session = request.getSession(true);
        System.out.println("user session: " + request.getSession());
        session.setAttribute("user", user);

        if (user.getRole().equalsIgnoreCase("admin")) {
            return "redirect:/admin/dashboard";
        } else if (user.getRole().equalsIgnoreCase("coach")) {
            return "redirect:/muscle_mentor_dashboard";
        } else {
            return "redirect:/profile";
        }

    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request, String username, String password) {
        HttpSession session = request.getSession();
        if (session != null) {
            session.invalidate();
            System.out.println("Log out OK");
        }
        return "login";
    }

    @PostMapping("/register")
    public String register(String username, String password, String email, String country, String phone, String role) {
        System.out.println(">> Register username: " + username);

        User user = new User(username, password, email, country, phone, role);
        userRepository.save(user);
        userRepository.flush();
        System.out.println(">> Saved user : " + user);

        return "login";

    }

    @PostMapping("/update")
    public String register(HttpServletRequest request, String email, String password, String address,
            String phoneNumber) {

        boolean loginOK = false;
        User user = null;
        HttpSession session = request.getSession();
        if (session != null) {
            user = (User) session.getAttribute("user");
            if (user != null) {
                loginOK = true;
            }
        }
        if (!loginOK) {
            return "redirect:/login";
        }
        user.setEmail(email);
        user.setPassword(password);
        user.setAddress(address);
        user.setPhoneNumber(phoneNumber);
        userRepository.save(user);
        userRepository.flush();
        System.out.println(">> Updated user : " + user);

        return "login";

    }

}
