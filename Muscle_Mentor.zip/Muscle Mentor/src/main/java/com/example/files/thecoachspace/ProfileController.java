package com.example.files.thecoachspace;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.files.theadminspace.FileDocument;
import com.example.files.model.User;
import com.example.files.repository.UserRepository;
import com.example.files.theadminspace.FileContentView;
import com.example.files.theadminspace.FileStorageService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.example.files.theadminspace.FileDocumentRepository;
import org.springframework.ui.Model;
import java.io.IOException;
import java.util.*;

@Controller
@RequestMapping("/profile")
public class ProfileController {

	private final UserRepository userRepository;

	public ProfileController(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@GetMapping
	public String profile(HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (session != null) {
			User user = (User) session.getAttribute("user");
			if (user != null) {
				return "MyProfile";
			}
		}
		return "redirect:/login";
	}

	@GetMapping("/edit")
	public String edit(HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (session != null) {
			User user = (User) session.getAttribute("user");
			if (user != null) {
				return "EditProfile";
			}
		}
		return "redirect:/login";
	}
        @PostMapping("/delete")
    public String deleteUser(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Check if the user is logged in
        if (user == null) {
            return "redirect:/login";
        }

        // Delete the user from the repository
        userRepository.delete(user);
        userRepository.flush();

        // Invalidate the session after deleting the account
        session.invalidate();

        // Redirect to the login page with a message indicating successful deletion
        return "redirect:/login?success=account_deleted";
    }

	
}