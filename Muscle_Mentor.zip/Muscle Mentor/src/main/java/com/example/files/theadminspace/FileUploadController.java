package com.example.files.theadminspace;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.ui.Model;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class FileUploadController {

    private final FileStorageService fileStorageService;
    private final FileDocumentRepository fileDocumentRepository;

    
    public FileUploadController(FileStorageService fileStorageService, FileDocumentRepository fileDocumentRepository) {
        this.fileStorageService = fileStorageService;
        this.fileDocumentRepository = fileDocumentRepository;
    }

    @GetMapping("/admin/files")
    public String listUploadedFiles(Model model) {
        List<FileDocument> files = fileStorageService.getAllFiles();
        List<FileContentView> fileContents = new ArrayList<>();
        for (FileDocument file : files) {
            Path path = Paths.get(file.getFilePath());
            String content;
            try {
                content = fileStorageService.readFileContent(path);
            } catch (IOException e) {
                
                content = "Error reading file content";
            }
            fileContents.add(new FileContentView(file.getId(), file.getFileName(), file.getUploader(), file.getStatus(), content));
        }
        model.addAttribute("files", fileContents);
        return "admin_files"; 
    }

    @PostMapping("/upload-file")
public String uploadFile(@RequestParam("file") MultipartFile file, 
                         @RequestParam("uploader") String uploader, 
                         @RequestParam("fileType") String fileType) throws IOException {
    if (!file.getContentType().equals("text/plain")) {
        throw new IllegalStateException("Only plain text files are allowed.");
    }
    FileDocument fileDocument = fileStorageService.storeFile(file, uploader);
    fileDocument.setFileType(fileType);
    fileDocumentRepository.save(fileDocument);
    return "redirect:/coach_upload";
}


    @PostMapping("/admin/approve/{id}")
public String approveFile(@PathVariable Long id) {
    Optional<FileDocument> fileDocumentOptional = fileDocumentRepository.findById(id);
    if (fileDocumentOptional.isPresent()) {
        FileDocument file = fileDocumentOptional.get();
        file.setStatus("Approved"); 
        fileDocumentRepository.save(file);
    } else {
        throw new RuntimeException("File not found");
    }
    return "redirect:/admin/dashboard";
}

    @PostMapping("/admin/deny/{id}")
public String denyFile(@PathVariable Long id) {
    Optional<FileDocument> fileDocumentOptional = fileDocumentRepository.findById(id);
    if (fileDocumentOptional.isPresent()) {
        FileDocument file = fileDocumentOptional.get();
        file.setStatus("Denied"); 
        fileDocumentRepository.save(file);
    } else {
        throw new RuntimeException("File not found");
    }
    return "redirect:/admin/dashboard";
}
    
    
    @PostMapping("/admin/delete/{id}")
    public String deleteFile(@PathVariable Long id) {
        try {
            fileStorageService.deleteFile(id);
        } catch (IOException e) {
            e.printStackTrace(); 
        }
        return "redirect:/admin/dashboard";
    }
}
