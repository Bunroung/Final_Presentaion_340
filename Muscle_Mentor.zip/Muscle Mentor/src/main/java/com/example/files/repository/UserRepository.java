package com.example.files.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.files.model.User;


@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
	User findByEmail (String email);
	
	List<User> findByRole(String role);

	User findByUsernameAndPassword(String username, String password);
	List<User> findByUsernameContainingOrEmailContaining(String username, String email);
 
    User findByUniquedId(int uniquedId);
}
