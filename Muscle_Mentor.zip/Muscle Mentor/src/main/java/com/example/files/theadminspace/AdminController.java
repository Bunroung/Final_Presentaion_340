package com.example.files.theadminspace;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.files.model.User;
import com.example.files.repository.UserRepository;
import java.util.Collections;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserRepository userRepository;
    private final FileStorageService fileStorageService;

    @Autowired
    public AdminController(UserRepository userRepository, FileStorageService fileStorageService) {
        this.userRepository = userRepository;
        this.fileStorageService = fileStorageService;
    }

    @GetMapping("/dashboard")
    public String getDashboard(Model model) {
        
        List<User> employees = userRepository.findByRole("ADMIN");
        employees.addAll(userRepository.findByRole("COACH"));
        employees.addAll(userRepository.findByRole("CREATOR"));
        employees.addAll(userRepository.findByRole("USER"));
        model.addAttribute("employees", employees);

        
        List<FileContentView> fileViews = fileStorageService.getAllFiles().stream()
            .map(fileDocument -> {
                String content;
                try {
                    content = fileStorageService.readFileContentById(fileDocument.getId());
                } catch (IOException e) {
                    content = "Error loading file content"; 
                }
                return new FileContentView(
                    fileDocument.getId(),
                    fileDocument.getFileName(),
                    fileDocument.getUploader(),
                    fileDocument.getStatus(),
                    content
                );
            }).collect(Collectors.toList());
        model.addAttribute("files", fileViews);

        return "admin_dashboard";
    }

    @GetMapping("/employees")
public String searchEmployees(@RequestParam(required = false) String search, Model model) {
    List<User> employees;
    if (search != null && !search.isEmpty()) {
       
        try {
            int searchId = Integer.parseInt(search);
            User employeeById = userRepository.findByUniquedId(searchId);
            employees = employeeById != null ? Collections.singletonList(employeeById) : Collections.emptyList();
        } catch (NumberFormatException e) {
            
            employees = userRepository.findByUsernameContainingOrEmailContaining(search, search);
        }
    } else {
        employees = userRepository.findByRole("ADMIN");
        employees.addAll(userRepository.findByRole("COACH"));
        employees.addAll(userRepository.findByRole("USER"));
        employees.addAll(userRepository.findByRole("CREATOR"));
    }
    model.addAttribute("employees", employees);
    return "admin_dashboard";
}

    @PostMapping("/employees/update/{id}")
    public String updateEmployeeRole(@PathVariable Long id, @RequestParam String role) {
        User user = userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id));
        user.setRole(role);
        userRepository.save(user);
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/employees/delete/{id}")
    public String deleteEmployee(@PathVariable Long id) {
        userRepository.deleteById(id);
        return "redirect:/admin/dashboard";
    }
}
