package com.example.files.theadminspace;

public class FileContentView {
    private Long id;
    private String fileName;
    private String uploader;
    private String status;
    private String content;

    
    public FileContentView(Long id, String fileName, String uploader, String status, String content) {
        this.id = id;
        this.fileName = fileName;
        this.uploader = uploader;
        this.status = status;
        this.content = content;
    }

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getUploader() {
        return uploader;
    }

    public void setUploader(String uploader) {
        this.uploader = uploader;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

