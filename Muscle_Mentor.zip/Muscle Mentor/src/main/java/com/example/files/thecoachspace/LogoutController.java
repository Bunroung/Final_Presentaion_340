package com.example.files.thecoachspace;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.files.theadminspace.FileDocument;
import com.example.files.model.User;
import com.example.files.repository.UserRepository;
import com.example.files.theadminspace.FileContentView;
import com.example.files.theadminspace.FileStorageService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.example.files.theadminspace.FileDocumentRepository;
import org.springframework.ui.Model;
import java.io.IOException;
import java.util.*;

@Controller
@RequestMapping("/logout")
public class LogoutController {

	private final UserRepository userRepository;

	public LogoutController(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@GetMapping
	public String logout(HttpServletRequest request, String username, String password) {
		HttpSession session = request.getSession();
		if (session != null) {
			session.invalidate();
			System.out.println("Log out OK");
		}
		return "login";
	}

}