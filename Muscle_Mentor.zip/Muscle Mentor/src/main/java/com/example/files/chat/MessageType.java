package com.example.files.chat;

public enum MessageType {

    CHAT,
    JOIN,
    LEAVE
}
