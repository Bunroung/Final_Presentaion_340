package com.example.files.theadminspace;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FileDocumentRepository extends JpaRepository<FileDocument, Long> {
    List<FileDocument> findByUploader(String uploader);
    List<FileDocument> findByStatus(String status);
    List<FileDocument> findByStatusAndFileType(String status, String fileType);
}

    

