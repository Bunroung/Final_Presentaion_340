package com.example.files.thecoachspace;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import com.example.files.theadminspace.FileDocument;
import com.example.files.theadminspace.FileContentView;
import com.example.files.theadminspace.FileStorageService;
import com.example.files.theadminspace.FileDocumentRepository;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.ui.Model;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class DashboardController {
    
    private final FileDocumentRepository fileDocumentRepository;
    private final FileStorageService fileStorageService;

    public DashboardController(FileDocumentRepository fileDocumentRepository, FileStorageService fileStorageService) {
        this.fileDocumentRepository = fileDocumentRepository;
        this.fileStorageService = fileStorageService;
    }

    @GetMapping("/muscle_mentor_dashboard")
    public String muscleMentorDashboard() {
        return "muscle_mentor_dashboard"; 
    }
    
    @GetMapping("/Personalized_fitness")
public String personalizedFitness(Model model) {
    List<FileDocument> fitnessFiles = fileDocumentRepository.findByStatusAndFileType("Approved", "fitness");
    List<FileContentView> fileContents = new ArrayList<>();
    for (FileDocument file : fitnessFiles) {
        try {
            String content = fileStorageService.readFileContentById(file.getId());
            fileContents.add(new FileContentView(file.getId(), file.getFileName(), file.getUploader(), file.getStatus(), content));
        } catch (IOException e) {
            
            fileContents.add(new FileContentView(file.getId(), file.getFileName(), file.getUploader(), file.getStatus(), "Error reading file content"));
        }
    }
    model.addAttribute("fitnessFiles", fileContents);
    return "Personalized_fitness";
}

@GetMapping("/Personalized_diet")
public String personalizedDiet(Model model) {
    List<FileDocument> dietFiles = fileDocumentRepository.findByStatusAndFileType("Approved", "diet");
    List<FileContentView> fileContents = new ArrayList<>();
    for (FileDocument file : dietFiles) {
        try {
            String content = fileStorageService.readFileContentById(file.getId());
            fileContents.add(new FileContentView(file.getId(), file.getFileName(), file.getUploader(), file.getStatus(), content));
        } catch (IOException e) {
            // Handle the case where the file could not be read
            fileContents.add(new FileContentView(file.getId(), file.getFileName(), file.getUploader(), file.getStatus(), "Error reading file content"));
        }
    }
    model.addAttribute("dietFiles", fileContents);
    return "Personalized_diet";
}

@GetMapping("/MyProfile")
    public String myProfilePage() {
        return "MyProfile";  
    }
    
        @GetMapping("/bmi")
    public String bmiPage() {
        return "bmi";  
    }
    
        @GetMapping("/home")
    public String homePage() {
        return "home";  
    }
    
        @GetMapping("/support")
    public String supportPage() {
        return "support";  
    }
    
    @GetMapping("/dashboard")
    public String userDashboardPage() {
        return "dashboard";  
    }
    
    @GetMapping("/admin_dashboard")
    public String adminDashboardPage() {
        return "admin_dashboard";  
    }
    
    @GetMapping("/coachProfile")
    public String coachProfilePage() {
        return "coachProfile";  
    }
    @GetMapping("/index")
    public String index() {
        return "index";  
    }
    @GetMapping("/privacypolicy")
    public String privacypolicy() {
        return "privacypolicy";  
    }
    @GetMapping("/login")
    public String login() {
        return "login"; 
    }
    @GetMapping("/rewardpromotion")
    public String rewardpromotion() {
        return "rewardpromotion";  
    }
    
    @GetMapping("/view_uploaded_files")
    public String viewCoachFiles(Model model) {

       
        List<FileContentView> fileViews = fileStorageService.getAllFiles().stream()
            .map(fileDocument -> {
                String content;
                try {
                    content = fileStorageService.readFileContentById(fileDocument.getId());
                } catch (IOException e) {
                    content = "Error loading file content"; 
                }
                return new FileContentView(
                    fileDocument.getId(),
                    fileDocument.getFileName(),
                    fileDocument.getUploader(),
                    fileDocument.getStatus(),
                    content
                );
            }).collect(Collectors.toList());
        model.addAttribute("files", fileViews);

        return "view_uploaded_files";
    }
    
    @PostMapping("/coach/delete/{id}")
    public String deleteCoachFile(@PathVariable Long id) {
        try {
            fileStorageService.deleteFile(id);
        } catch (IOException e) {
            
            System.err.println("Error deleting file: " + e.getMessage());
        }
        return "redirect:/view_uploaded_files"; 
    }

    

}