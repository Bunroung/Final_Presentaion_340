package com.example.files.theadminspace;

import java.io.FileNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.util.StringUtils;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@Service
public class FileStorageService {

    private final FileDocumentRepository fileDocumentRepository;
    private final Path fileStorageLocation = Paths.get("uploads").toAbsolutePath().normalize();

    public FileStorageService(FileDocumentRepository fileDocumentRepository) {
        this.fileDocumentRepository = fileDocumentRepository;
        try {
            Files.createDirectories(this.fileStorageLocation);
        } catch (IOException e) {
            throw new RuntimeException("Could not create file storage directory", e);
        }
    }

    public FileDocument storeFile(MultipartFile file, String uploader) throws IOException {
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        Path targetLocation = this.fileStorageLocation.resolve(fileName);
        file.transferTo(targetLocation);

        FileDocument fileDocument = new FileDocument();
        fileDocument.setFileName(fileName);
        fileDocument.setFilePath(targetLocation.toString());
        fileDocument.setUploader(uploader);
        return fileDocumentRepository.save(fileDocument);
    }

    public List<FileDocument> getAllFiles() {
        return fileDocumentRepository.findAll();
    }



    public String readFileContent(Path filePath) throws IOException {
    return new String(Files.readAllBytes(filePath), StandardCharsets.UTF_8);
}

    
    public void deleteFile(Long fileId) throws IOException {
        Optional<FileDocument> fileDocument = fileDocumentRepository.findById(fileId);
        if (fileDocument.isPresent()) {
            Path filePath = Paths.get(fileDocument.get().getFilePath());
            Files.deleteIfExists(filePath); // Delete the file from the filesystem
            fileDocumentRepository.delete(fileDocument.get()); // Remove the file record from the database
        }
    }
    
    
    public String readFileContentById(Long id) throws IOException {
    Optional<FileDocument> fileDocument = fileDocumentRepository.findById(id);
    if (fileDocument.isPresent()) {
        Path path = Paths.get(fileDocument.get().getFilePath());
        return new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
    }
    throw new FileNotFoundException("File not found with id: " + id);
}

}