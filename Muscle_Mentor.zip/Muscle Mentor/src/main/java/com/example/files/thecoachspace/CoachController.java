package com.example.files.thecoachspace;
import com.example.files.theadminspace.FileDocument;
import com.example.files.theadminspace.FileDocumentRepository;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class CoachController {

    private final FileDocumentRepository fileDocumentRepository;

    public CoachController(FileDocumentRepository fileDocumentRepository) {
        this.fileDocumentRepository = fileDocumentRepository;
    }

    @GetMapping("/coach/files")
    public String listCoachFiles(Model model, @RequestParam(required = false) String uploader) {
       
        if (uploader == null || uploader.isEmpty()) {
            model.addAttribute("error", "No uploader specified.");
            return "coach_upload"; // Display an error message or redirect as needed
        }

        
        List<FileDocument> files = fileDocumentRepository.findByUploader(uploader);
        if (files.isEmpty()) {
            model.addAttribute("message", "No files uploaded by this coach.");
        } else {
            model.addAttribute("files", files);
        }
        return "coach_upload"; 
    }
    

    @GetMapping("/coach_upload")
public String coachUploadPage() {
    return "coach_upload";  
}

}