-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 30, 2024 at 04:52 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `files_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('ADMIN','COACH','CREATOR') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `username`, `email`, `password`, `role`) VALUES
(10000000000, 'Sara_admin', 'sara_admin@musclementor.com', '***********', 'ADMIN'),
(10000000001, 'Ronaldo_king', 'Ronaldo_king@musclementor.com', '***********', 'COACH'),
(10000000002, 'Bob_builder', 'Bob_builder@musclementor.com', '***********', 'CREATOR'),
(10000000003, 'Alissa_allen', 'Alissa_allen@musclementor.com', '***********', 'ADMIN'),
(10000000004, 'Messi_notking', 'Messi_notking@musclementor.com', '***********', 'COACH'),
(10000000005, 'Jane_juice', 'Jane_juice@musclementor.com', '***********', 'ADMIN'),
(10000000006, 'Tom_creator', 'Tom_creator@musclementor.com', '***********', 'CREATOR'),
(10000000007, 'Lucy_lunatic', 'Lucy_lunatic@musclementor.com', '***********', 'COACH'),
(10000000008, 'Mark_moose', 'Mark_moose@musclementor.com', '***********', 'ADMIN'),
(10000000009, 'Sophia_sauce', 'Sophia_sauce@musclementor.com', '***********', 'CREATOR'),
(10000000010, 'Amna_Sohail', 'Amna_Sohail@musclementor.com', '***********', 'CREATOR'),
(10000000011, 'Fady_Eskandr', 'Fady_Eskandr@musclementor.com', '***********', 'COACH');

-- --------------------------------------------------------

--
-- Table structure for table `FileDocument`
--

CREATE TABLE `FileDocument` (
  `id` bigint(20) NOT NULL,
  `fileName` varchar(255) DEFAULT NULL,
  `filePath` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `uploader` varchar(255) DEFAULT NULL,
  `fileType` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `uniquedId` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `uniqueId` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `address`, `age`, `email`, `fullname`, `password`, `phoneNumber`, `role`, `uniquedId`, `username`, `uniqueId`) VALUES
(102, NULL, 0, 'newuser123@gmail.com', NULL, 'newuser123', 'ghksg', 'USER', 1246505, 'newuser', NULL),
(202, NULL, 0, 'Saraadmin@gmail.com', NULL, 'saraadmin', '3367401257', 'ADMIN', 4847393, 'Sara_admin', NULL),
(203, NULL, 0, 'amnacreator@gmail.com', NULL, 'amnacreator', '336879278', 'CREATOR', 8270573, 'Amna_creator', NULL),
(204, NULL, 0, 'Fadyeskandr7@gmail.com', NULL, 'Fadyeskand2', '(919) 539-4582', 'COACH', 2260188, 'Faeskandr', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_SEQ`
--

CREATE TABLE `users_SEQ` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_SEQ`
--

INSERT INTO `users_SEQ` (`next_val`) VALUES
(301);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `FileDocument`
--
ALTER TABLE `FileDocument`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10000000012;

--
-- AUTO_INCREMENT for table `FileDocument`
--
ALTER TABLE `FileDocument`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
